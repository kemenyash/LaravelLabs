﻿const savedTheme = localStorage.getItem('theme');
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
const initialTheme = savedTheme || (prefersDark ? 'dark' : 'light');
document.body.classList.toggle('dark', initialTheme === 'dark');
localStorage.setItem('theme', initialTheme);

const lightTile = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
const darkTile = L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png');
const useDark = initialTheme === 'dark';
const map = L.map('map', { layers: [useDark ? darkTile : lightTile] }).setView([50.4501, 30.5234], 7);
let currentTile = useDark ? darkTile : lightTile;

let pointA = null, pointB = null, markerA = null, markerB = null, routeLayer = null, routeData = null;

const themeBtn = document.getElementById('toggleTheme');
themeBtn.textContent = useDark ? '🌞' : '🌙';
['mousedown', 'click', 'dblclick'].forEach(evt =>
    themeBtn.addEventListener(evt, e => e.stopPropagation()));

themeBtn.onclick = () => {
    document.body.classList.toggle('dark');
    const isDark = document.body.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    map.removeLayer(currentTile);
    currentTile = isDark ? darkTile : lightTile;
    map.addLayer(currentTile);
    themeBtn.textContent = isDark ? '🌞' : '🌙';
};

['mousedown', 'click', 'dblclick'].forEach(evt =>
    document.getElementById('controlsPanel').addEventListener(evt, e => e.stopPropagation()));

document.getElementById('resetBtn').onclick = () => {
    [pointA, pointB, routeData] = [null, null, null];
    if (markerA) map.removeLayer(markerA);
    if (markerB) map.removeLayer(markerB);
    if (routeLayer) map.removeLayer(routeLayer);
    document.getElementById('info').textContent = 'Натисніть на карту або введіть місця';
};

document.getElementById('profile').addEventListener('change', () => {
    if (pointA && pointB) drawRoute(pointA, pointB);
});

document.getElementById('searchBtn').onclick = async () => {
    const from = document.getElementById('fromInput').value;
    const to = document.getElementById('toInput').value;
    if (!from || !to) return alert('Введіть обидва місця');

    const coordFrom = await geocodePlace(from);
    const coordTo = await geocodePlace(to);
    if (!coordFrom || !coordTo) return alert('Не знайдено координати для одного з місць');

    document.getElementById('resetBtn').click();
    pointA = L.latLng(coordFrom.y, coordFrom.x);
    pointB = L.latLng(coordTo.y, coordTo.x);
    markerA = L.marker(pointA).addTo(map).bindPopup('Старт').openPopup();
    markerB = L.marker(pointB).addTo(map).bindPopup('Фініш').openPopup();
    drawRoute(pointA, pointB);
};

async function geocodePlace(query) {
    try {
        const provider = new window.GeoSearch.OpenStreetMapProvider();
        const results = await provider.search({ query });
        return results[0];
    } catch {
        return null;
    }
}

function drawRoute(from, to) {
    const profile = document.getElementById('profile').value;
    const url = `https://localhost:6680/api/route?fromLat=${from.lat}&fromLng=${from.lng}&toLat=${to.lat}&toLng=${to.lng}&profile=${profile}`;

    fetch(url)
        .then(res => res.json())
        .then(data => {
            if (routeLayer) map.removeLayer(routeLayer);
            routeData = data;
            const latLngs = data.map(c => [c[1], c[0]]);
            routeLayer = L.polyline(latLngs, { color: '#4285f4', weight: 5 }).addTo(map);
            map.fitBounds(routeLayer.getBounds());

            let lengthKm = 0;
            for (let i = 1; i < latLngs.length; i++) {
                lengthKm += map.distance(latLngs[i - 1], latLngs[i]);
            }
            lengthKm /= 1000;

            const speedMap = { car: 60, bike: 15, foot: 5 };
            const speed = speedMap[profile] || 40;
            let durationMin = (lengthKm / speed) * 60;

            let timeText = '';
            if (durationMin < 60) {
                timeText = `${Math.ceil(durationMin)} хв`;
            } else if (durationMin < 1440) {
                const h = Math.floor(durationMin / 60);
                const m = Math.round(durationMin % 60);
                timeText = `${h} год ${m} хв`;
            } else {
                const d = Math.floor(durationMin / 1440);
                const h = Math.round((durationMin % 1440) / 60);
                timeText = `${d} дн ${h} год`;
            }

            document.getElementById('info').textContent = `📏 ${lengthKm.toFixed(2)} км | 🕒 ~${timeText}`;
        })
        .catch(err => {
            console.error(err);
            alert("Не вдалося побудувати маршрут");
        });
}

map.on('click', e => {
    if (pointA && pointB) document.getElementById('resetBtn').click();
    if (!pointA) {
        pointA = e.latlng;
        markerA = L.marker(pointA).addTo(map).bindPopup('Початок маршруту').openPopup();
    } else if (!pointB) {
        pointB = e.latlng;
        markerB = L.marker(pointB).addTo(map).bindPopup('Місце призначення').openPopup();
        drawRoute(pointA, pointB);
    }
});