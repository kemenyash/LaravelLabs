﻿const API_BASE = "http://localhost:5037";
let currentUserRole = localStorage.getItem("role") || null;
let allCars = [];

async function submitNewCar(e) {
    e.preventDefault();
    const form = e.target;

    const car = {
        brand: form.brand.value,
        color: form.color.value,
        year: parseInt(form.year.value),
        isNew: form.isNew.value === "true",
        price: parseFloat(form.price.value),
        photo: form.photo.value,
        description: form.description.value
    };

    try {
        const res = await fetch("http://localhost:5037/api/cars", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Token": localStorage.getItem("token"),
                "UserId": localStorage.getItem("userId")
            },
            body: JSON.stringify(car)
        });

        if (!res.ok) {
            if (res.status === 401) {
                showToast("Авторизація не пройдена. Перевірте токен і UserId.", "error");
            } else {
                showToast("Помилка сервера: " + res.status, "error");
            }
            return;
        }

        showToast("Авто додано успішно", "success");
        form.reset();
        closeDialog("addCarDialog");
        loadCars();

    } catch (err) {
        console.error("Помилка при запиті:", err);
        showToast("Не вдалося з'єднатися з сервером", "error");
    }
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("authBtn").textContent = currentUserRole ? "Вийти" : "Авторизація";
    document.getElementById("addCarBtn").style.display = currentUserRole === "admin" ? "inline-block" : "none";
    loadCars();
});

function closeDialog(id) {
    document.getElementById(id).close();
}

async function loadCars() {
    try {
        const res = await fetch(`${API_BASE}/api/cars`);
        if (!res.ok) throw new Error("Failed to load cars");
        allCars = await res.json();
        renderCarList(allCars);
        updateFilters(allCars);
    } catch (err) {
        console.error("Помилка завантаження машин:", err);
        document.getElementById("noResultsMessage").style.display = "block";
    }
}

function showAddCarDialog() {
    const dialog = document.getElementById("addCarDialog");
    const form = document.getElementById("addCarForm");

    form.reset();
    form.onsubmit = submitNewCar;

    dialog.showModal();
}

function renderCarList(cars) {
    const list = document.getElementById("carList");
    const noResults = document.getElementById("noResultsMessage");
    list.innerHTML = "";

    if (!cars.length) {
        list.innerHTML = "";
        list.classList.remove("single");
        noResults.style.display = "block";
        return;
    }

    noResults.style.display = "none";
    list.classList.toggle("single", cars.length === 1);

    cars.forEach(car => {
        const div = document.createElement("div");
        div.className = "car-card";
        div.innerHTML = `
          <img src="${car.photo}" alt="${car.brand}">
          <h4>${car.brand} (${car.year})</h4>
          <span class="price">${car.price} грн</span>
        `;

        div.onclick = () => showCarDetails(car);

        if (currentUserRole === "admin") {
            const controls = document.createElement("div");
            controls.className = "admin-controls";

            const editBtn = document.createElement("button");
            editBtn.textContent = "Редагувати";
            editBtn.onclick = (e) => {
                e.stopPropagation();
                showEditCarDialog(car);
            };

            const deleteBtn = document.createElement("button");
            deleteBtn.textContent = "Видалити";
            deleteBtn.onclick = (e) => {
                e.stopPropagation();
                deleteCar(car.id);
            };

            controls.appendChild(editBtn);
            controls.appendChild(deleteBtn);
            div.appendChild(controls);
        }

        list.appendChild(div);
    });
}

function handleAuthButton() {
    if (currentUserRole) {
        localStorage.removeItem("token");
        localStorage.removeItem("userId");
        localStorage.removeItem("role");
        currentUserRole = null;
        location.reload();
    } else {
        showAuthDialog();
    }
}

let isRegisterMode = false;
function showAuthDialog() {
    isRegisterMode = false;
    updateAuthForm();
    document.getElementById("authDialog").showModal();
}

function switchToRegister() {
    isRegisterMode = true;
    updateAuthForm();
}

function switchToLogin() {
    isRegisterMode = false;
    updateAuthForm();
}

function updateAuthForm() {
    const authContent = document.getElementById("authContent");
    if (isRegisterMode) {
        authContent.innerHTML = `
          <h3>Реєстрація</h3>
          <form id="registerForm">
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="text" name="fullName" placeholder="П.І.Б" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Зареєструватися</button>
          </form>
          <p>Вже маєте акаунт? <button onclick="switchToLogin()" style="background:none; border:none; color:var(--accent)">Авторизація</button></p>
        `;
        document.getElementById("registerForm").onsubmit = submitRegister;
    } else {
        authContent.innerHTML = `
          <h3>Авторизація</h3>
          <form id="loginForm">
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Увійти</button>
          </form>
          <p>Немає акаунту? <button onclick="switchToRegister()" style="background:none; border:none; color:var(--accent)">Реєстрація</button></p>
        `;
        document.getElementById("loginForm").onsubmit = submitLogin;
    }
}

async function submitLogin(e) {
    e.preventDefault();
    const form = e.target;
    const data = {
        email: form.email.value,
        password: form.password.value
    };

    try {
        const res = await fetch(`${API_BASE}/api/auth/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        if (!res.ok) {
            showToast("Помилка авторизації", "error");
            return;
        }

        const result = await res.json();
        localStorage.setItem("token", result.token);
        localStorage.setItem("userId", result.userId);
        localStorage.setItem("role", result.role);

        currentUserRole = result.role;
        document.getElementById("authBtn").textContent = "Вийти";
        if (currentUserRole === "admin") document.getElementById("addCarBtn").style.display = 'block';
        closeDialog("authDialog");
        location.reload();
    } catch (err) {
        showToast("Помилка підключення до сервера", "error");
        console.error(err);
    }
}

async function submitRegister(e) {
    e.preventDefault();
    const form = e.target;
    const data = {
        email: form.email.value,
        fullName: form.fullName.value,
        password: form.password.value
    };

    try {
        const res = await fetch(`${API_BASE}/api/auth/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        if (!res.ok) {
            const text = await res.text();
            showToast("Помилка реєстрації: " + text, "error");
            return;
        }

        showToast("Реєстрація успішна", "success");
        closeDialog("authDialog");

    } catch (err) {
        showToast("Помилка з'єднання з сервером", "error");
        console.error(err);
    }
}

async function deleteCar(id) {
    if (!confirm("Ви впевнені, що хочете видалити це авто?")) return;

    try {
        const res = await fetch(`${API_BASE}/api/cars/${id}`, {
            method: "DELETE",
            headers: {
                "Token": localStorage.getItem("token"),
                "UserId": localStorage.getItem("userId")
            }
        });

        if (!res.ok) {
            showToast("Помилка при видаленні", "error");
            return;
        }
        showToast("Успішно видалено", "success");
        await loadCars();
    } catch (err) {
        console.error("Помилка при видаленні:", err);
        showToast("Не вдалося підключитися до сервера", "error");
    }
}

function showEditCarDialog(car) {
    const dialog = document.getElementById("addCarDialog");
    const form = document.getElementById("addCarForm");

    form.brand.value = car.brand;
    form.color.value = car.color;
    form.year.value = car.year;
    form.isNew.value = car.isNew.toString();
    form.price.value = car.price;
    form.photo.value = car.photo;
    form.description.value = car.description;

    form.onsubmit = (e) => submitEditCar(e, car.id);
    dialog.showModal();
}

async function submitEditCar(e, carId) {
    e.preventDefault();
    const form = e.target;

    const updatedCar = {
        brand: form.brand.value,
        color: form.color.value,
        year: parseInt(form.year.value),
        isNew: form.isNew.value === "true",
        price: parseFloat(form.price.value),
        photo: form.photo.value,
        description: form.description.value
    };

    try {
        const res = await fetch(`${API_BASE}/api/cars/${carId}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                "Token": localStorage.getItem("token"),
                "UserId": localStorage.getItem("userId")
            },
            body: JSON.stringify(updatedCar)
        });

        if (!res.ok) {
            showToast("Помилка при редагуванні", "error");
            return;
        }

        showToast("Зміни збережено", "success");
        closeDialog("addCarDialog");
        loadCars();
    } catch (err) {
        console.error("Помилка редагування:", err);
        showToast("Не вдалося підключитися до сервера", "error");
    }
}

function updateFilters(cars) {
    const brandSet = new Set();
    const colorSet = new Set();
    const yearSet = new Set();

    cars.forEach(car => {
        brandSet.add(car.brand);
        colorSet.add(car.color);
        yearSet.add(car.year);
    });

    fillSelect("brandFilter", brandSet, "Марка");
    fillSelect("colorFilter", colorSet, "Колір");
    fillSelect("yearFilter", yearSet, "Рік");
}

function fillSelect(selectId, valuesSet, defaultLabel) {
    const select = document.getElementById(selectId);
    const prevValue = select.value;
    select.innerHTML = `<option value="">${defaultLabel}</option>`;
    [...valuesSet].sort().forEach(val => {
        const option = document.createElement("option");
        option.value = val;
        option.textContent = val;
        select.appendChild(option);
    });
    if ([...valuesSet].includes(prevValue)) select.value = prevValue;
}

function showToast(message, type = "success") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;

    document.getElementById("toastContainer").appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 4000);
}

function applyFilters() {
    const query = document.getElementById("searchInput").value.trim().toLowerCase();
    const condition = document.getElementById("conditionFilter").value;
    const brand = document.getElementById("brandFilter").value;
    const color = document.getElementById("colorFilter").value;
    const year = document.getElementById("yearFilter").value;

    const filtered = allCars.filter(car => {
        const matchesQuery = !query || car.brand.toLowerCase().includes(query) || car.description.toLowerCase().includes(query);
        const matchesCondition = !condition || (condition === "new" && car.isNew) || (condition === "used" && !car.isNew);
        const matchesBrand = !brand || car.brand === brand;
        const matchesColor = !color || car.color === color;
        const matchesYear = !year || car.year.toString() === year;
        return matchesQuery && matchesCondition && matchesBrand && matchesColor && matchesYear;
    });

    renderCarList(filtered);
}

function showCarDetails(car) {
    const content = `
        <h3>${car.brand} (${car.year})</h3>
        <img src="${car.photo}" alt="${car.brand}" style="width:100%; max-height:200px; object-fit:cover; border-radius:8px; margin:1rem 0">
        <p><strong>Колір:</strong> ${car.color}</p>
        <p><strong>Стан:</strong> ${car.isNew ? 'Нове' : 'Б/в'}</p>
        <p><strong>Ціна:</strong> ${car.price} грн.</p>
        <p><strong>Опис:</strong> ${car.description}</p>
      `;

    document.getElementById("carDetailsContent").innerHTML = content;
    document.getElementById("carDetailsDialog").showModal();
}
